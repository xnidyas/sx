<?php

$XCStreamHostUrl = 'http://{{YourDNS}}:{{YourIP}}';
$XClogoLinkval = 'images/iptv-premium-logo-200.png';
$XCcopyrighttextval = '';
$XCcontactUslinkval = '';
$XChelpLinkval = '';
$XClicenseIsval = 'Web-384884f8a2';
$XClocalKey = '';
$XCsitetitleval = 'Player TV';

?> 
