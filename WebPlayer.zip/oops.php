<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 */

echo "<!DOCTYPE html>\r\n<html>\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n    <title>OOPS..Something Went Wrong</title>\r\n    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,300italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>\r\n    <link href=\"https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900\" rel=\"stylesheet\">\r\n</head>\r\n\r\n<body style=\"background: #cfe6f7  url('images/oops.png') no-repeat; background-position: 50% 50%; background-size: 30%;\">\r\n<h2 style=\"text-align: center; padding-top: 300px; font-family: Raleway;\">Could not contact to Server. Please Conatct Administrator.</h2>\r\n\r\n</body>\r\n</html>";

?>